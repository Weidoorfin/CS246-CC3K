export module position;

export struct Position {
    int x, y;
};
